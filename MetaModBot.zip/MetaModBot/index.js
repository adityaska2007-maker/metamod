const { Client, GatewayIntentBits, PermissionFlagsBits, EmbedBuilder, SlashCommandBuilder, REST, Routes } = require('discord.js');

// Configuration
const CONFIG = {
    OWNER_ID: '1413204709162090596',
    SUPPORT_SERVER: 'https://discord.gg/U23SVpQWzm',
    COLORS: {
        PRIMARY: 0x5865F2,
        SUCCESS: 0x57F287,
        WARNING: 0xFEE75C,
        DANGER: 0xED4245,
        INFO: 0x5DADE2
    }
};

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildModeration
    ],
    allowedMentions: { parse: [] }
});

// Helper function to create professional embeds
function createEmbed(options = {}) {
    const embed = new EmbedBuilder()
        .setColor(options.color || CONFIG.COLORS.PRIMARY)
        .setTimestamp()
        .setFooter({ 
            text: `META MOD • Support: ${CONFIG.SUPPORT_SERVER}`,
            iconURL: client.user?.displayAvatarURL()
        });

    if (options.title) embed.setTitle(options.title);
    if (options.description) embed.setDescription(options.description);
    if (options.thumbnail) embed.setThumbnail(options.thumbnail);
    if (options.author) embed.setAuthor(options.author);
    if (options.fields) embed.addFields(options.fields);
    if (options.image) embed.setImage(options.image);

    return embed;
}

// Error embed helper
function createErrorEmbed(message) {
    return createEmbed({
        color: CONFIG.COLORS.DANGER,
        title: '❌ Error',
        description: message
    });
}

// Success embed helper
function createSuccessEmbed(title, description, fields = []) {
    return createEmbed({
        color: CONFIG.COLORS.SUCCESS,
        title,
        description,
        fields
    });
}

const commands = [
    new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a member from the server')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to kick')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('reason')
                .setDescription('Reason for kicking')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a member from the server')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to ban')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('reason')
                .setDescription('Reason for banning')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a user from the server')
        .addStringOption(option => 
            option.setName('userid')
                .setDescription('The user ID to unban')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('reason')
                .setDescription('Reason for unbanning')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('Timeout a member')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to timeout')
                .setRequired(true))
        .addIntegerOption(option => 
            option.setName('duration')
                .setDescription('Duration in minutes')
                .setRequired(true))
        .addStringOption(option => 
            option.setName('reason')
                .setDescription('Reason for timeout')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('untimeout')
        .setDescription('Remove timeout from a member')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to remove timeout from')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Delete multiple messages from a channel')
        .addIntegerOption(option => 
            option.setName('amount')
                .setDescription('Number of messages to delete (1-100)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(100))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('history')
        .setDescription('View message history for a user')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('The user to view history for')
                .setRequired(true))
        .addIntegerOption(option => 
            option.setName('limit')
                .setDescription('Number of messages to retrieve (1-50)')
                .setRequired(false)
                .setMinValue(1)
                .setMaxValue(50))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('about')
        .setDescription('Get information about META MOD bot')
        .setDMPermission(false),

    new SlashCommandBuilder()
        .setName('support')
        .setDescription('Get support server link and bot information')
        .setDMPermission(false)
];

client.once('ready', async () => {
    console.log(`✅ META MOD is online as ${client.user.tag}!`);
    
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    
    try {
        console.log('🔄 Registering slash commands...');
        
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands.map(cmd => cmd.toJSON()) }
        );
        
        console.log('✅ Slash commands registered successfully!');
    } catch (error) {
        console.error('❌ Error registering commands:', error);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const { commandName } = interaction;

    try {
        switch (commandName) {
            case 'kick': {
                const user = interaction.options.getUser('user');
                const reason = interaction.options.getString('reason') || 'No reason provided';
                
                let member;
                try {
                    member = await interaction.guild.members.fetch(user.id);
                } catch (error) {
                    return interaction.reply({ 
                        embeds: [createErrorEmbed('User not found in this server.')], 
                        ephemeral: true 
                    });
                }

                if (!member.kickable) {
                    return interaction.reply({ 
                        embeds: [createErrorEmbed('I cannot kick this user. They may have higher permissions than me.')], 
                        ephemeral: true 
                    });
                }

                await member.kick(reason);
                
                const embed = createEmbed({
                    color: CONFIG.COLORS.DANGER,
                    author: { 
                        name: 'META MOD • Member Kicked',
                        iconURL: client.user.displayAvatarURL()
                    },
                    thumbnail: user.displayAvatarURL({ dynamic: true }),
                    fields: [
                        { name: '👤 User', value: `${user.tag}\n\`${user.id}\``, inline: true },
                        { name: '🛡️ Moderator', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: true },
                        { name: '📋 Reason', value: reason, inline: false }
                    ]
                });

                await interaction.reply({ embeds: [embed] });
                console.log(`[KICK] ${user.tag} (${user.id}) kicked by ${interaction.user.tag} - Reason: ${reason}`);
                break;
            }

            case 'ban': {
                const user = interaction.options.getUser('user');
                const reason = interaction.options.getString('reason') || 'No reason provided';
                
                let member;
                try {
                    member = await interaction.guild.members.fetch(user.id);
                    if (!member.bannable) {
                        return interaction.reply({ 
                            embeds: [createErrorEmbed('I cannot ban this user. They may have higher permissions than me.')], 
                            ephemeral: true 
                        });
                    }
                } catch (error) {
                }

                await interaction.guild.members.ban(user, { reason });
                
                const embed = createEmbed({
                    color: CONFIG.COLORS.DANGER,
                    author: { 
                        name: 'META MOD • Member Banned',
                        iconURL: client.user.displayAvatarURL()
                    },
                    thumbnail: user.displayAvatarURL({ dynamic: true }),
                    fields: [
                        { name: '👤 User', value: `${user.tag}\n\`${user.id}\``, inline: true },
                        { name: '🛡️ Moderator', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: true },
                        { name: '📋 Reason', value: reason, inline: false },
                        { name: '⚠️ Status', value: 'User has been permanently banned from this server', inline: false }
                    ]
                });

                await interaction.reply({ embeds: [embed] });
                console.log(`[BAN] ${user.tag} (${user.id}) banned by ${interaction.user.tag} - Reason: ${reason}`);
                break;
            }

            case 'unban': {
                const userId = interaction.options.getString('userid');
                const reason = interaction.options.getString('reason') || 'No reason provided';

                try {
                    const bannedUser = await interaction.guild.bans.fetch(userId);
                    await interaction.guild.bans.remove(userId, reason);
                    
                    const embed = createEmbed({
                        color: CONFIG.COLORS.SUCCESS,
                        author: { 
                            name: 'META MOD • User Unbanned',
                            iconURL: client.user.displayAvatarURL()
                        },
                        thumbnail: bannedUser.user.displayAvatarURL({ dynamic: true }),
                        fields: [
                            { name: '👤 User', value: `${bannedUser.user.tag}\n\`${userId}\``, inline: true },
                            { name: '🛡️ Moderator', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: true },
                            { name: '📋 Reason', value: reason, inline: false },
                            { name: '✅ Status', value: 'User can now rejoin the server', inline: false }
                        ]
                    });

                    await interaction.reply({ embeds: [embed] });
                    console.log(`[UNBAN] User ${userId} unbanned by ${interaction.user.tag} - Reason: ${reason}`);
                } catch (error) {
                    await interaction.reply({ 
                        embeds: [createErrorEmbed('Failed to unban user. Please check if the user ID is correct and the user is actually banned.')], 
                        ephemeral: true 
                    });
                }
                break;
            }

            case 'timeout': {
                const user = interaction.options.getUser('user');
                const duration = interaction.options.getInteger('duration');
                const reason = interaction.options.getString('reason') || 'No reason provided';
                
                let member;
                try {
                    member = await interaction.guild.members.fetch(user.id);
                } catch (error) {
                    return interaction.reply({ 
                        embeds: [createErrorEmbed('User not found in this server.')], 
                        ephemeral: true 
                    });
                }

                if (!member.moderatable) {
                    return interaction.reply({ 
                        embeds: [createErrorEmbed('I cannot timeout this user. They may have higher permissions than me.')], 
                        ephemeral: true 
                    });
                }

                const timeoutDuration = duration * 60 * 1000;
                const expiresAt = new Date(Date.now() + timeoutDuration);
                await member.timeout(timeoutDuration, reason);
                
                const embed = createEmbed({
                    color: CONFIG.COLORS.WARNING,
                    author: { 
                        name: 'META MOD • Member Timed Out',
                        iconURL: client.user.displayAvatarURL()
                    },
                    thumbnail: user.displayAvatarURL({ dynamic: true }),
                    fields: [
                        { name: '👤 User', value: `${user.tag}\n\`${user.id}\``, inline: true },
                        { name: '🛡️ Moderator', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: true },
                        { name: '⏱️ Duration', value: `${duration} minutes`, inline: true },
                        { name: '⏰ Expires At', value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:F>`, inline: true },
                        { name: '📋 Reason', value: reason, inline: false }
                    ]
                });

                await interaction.reply({ embeds: [embed] });
                console.log(`[TIMEOUT] ${user.tag} (${user.id}) timed out for ${duration} minutes by ${interaction.user.tag} - Reason: ${reason}`);
                break;
            }

            case 'untimeout': {
                const user = interaction.options.getUser('user');
                
                let member;
                try {
                    member = await interaction.guild.members.fetch(user.id);
                } catch (error) {
                    return interaction.reply({ 
                        embeds: [createErrorEmbed('User not found in this server.')], 
                        ephemeral: true 
                    });
                }

                if (!member.isCommunicationDisabled()) {
                    return interaction.reply({ 
                        embeds: [createErrorEmbed('This user is not currently timed out.')], 
                        ephemeral: true 
                    });
                }

                await member.timeout(null);
                
                const embed = createEmbed({
                    color: CONFIG.COLORS.SUCCESS,
                    author: { 
                        name: 'META MOD • Timeout Removed',
                        iconURL: client.user.displayAvatarURL()
                    },
                    thumbnail: user.displayAvatarURL({ dynamic: true }),
                    fields: [
                        { name: '👤 User', value: `${user.tag}\n\`${user.id}\``, inline: true },
                        { name: '🛡️ Moderator', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: true },
                        { name: '✅ Status', value: 'User can now communicate in the server', inline: false }
                    ]
                });

                await interaction.reply({ embeds: [embed] });
                console.log(`[UNTIMEOUT] ${user.tag} (${user.id}) timeout removed by ${interaction.user.tag}`);
                break;
            }

            case 'purge': {
                const amount = interaction.options.getInteger('amount');

                await interaction.deferReply({ ephemeral: true });

                const deletedMessages = await interaction.channel.bulkDelete(amount, true);

                const embed = createEmbed({
                    color: CONFIG.COLORS.INFO,
                    author: { 
                        name: 'META MOD • Messages Purged',
                        iconURL: client.user.displayAvatarURL()
                    },
                    thumbnail: interaction.guild.iconURL({ dynamic: true }),
                    fields: [
                        { name: '📺 Channel', value: `${interaction.channel.name}\n\`${interaction.channel.id}\``, inline: true },
                        { name: '🔢 Requested', value: `${amount} messages`, inline: true },
                        { name: '🗑️ Deleted', value: `${deletedMessages.size} messages`, inline: true },
                        { name: '🛡️ Moderator', value: `${interaction.user.tag}\n\`${interaction.user.id}\``, inline: false },
                        { name: 'ℹ️ Note', value: 'Messages older than 14 days cannot be bulk deleted', inline: false }
                    ]
                });

                await interaction.editReply({ embeds: [embed] });
                console.log(`[PURGE] ${deletedMessages.size} messages deleted in ${interaction.channel.name} by ${interaction.user.tag}`);
                break;
            }

            case 'history': {
                const user = interaction.options.getUser('user');
                const limit = interaction.options.getInteger('limit') || 10;

                await interaction.deferReply({ ephemeral: true });

                const messages = await interaction.channel.messages.fetch({ limit: 100 });
                const userMessages = messages.filter(msg => msg.author.id === user.id).first(limit);

                if (userMessages.length === 0) {
                    return interaction.editReply({ 
                        embeds: [createErrorEmbed(`No messages found from ${user.tag} in this channel.`)] 
                    });
                }

                const historyText = userMessages.map((msg, index) => {
                    const timestamp = `<t:${Math.floor(msg.createdTimestamp / 1000)}:f>`;
                    const content = msg.content || '*[No text content]*';
                    return `**${index + 1}.** ${timestamp}\n${content.substring(0, 200)}${content.length > 200 ? '...' : ''}`;
                }).join('\n\n');

                const embed = createEmbed({
                    color: CONFIG.COLORS.INFO,
                    author: { 
                        name: `META MOD • Message History`,
                        iconURL: client.user.displayAvatarURL()
                    },
                    title: `📜 Messages from ${user.tag}`,
                    description: historyText.substring(0, 4000),
                    thumbnail: user.displayAvatarURL({ dynamic: true }),
                    fields: [
                        { name: '📺 Channel', value: `${interaction.channel.name}`, inline: true },
                        { name: '🔢 Messages Found', value: `${userMessages.length}`, inline: true },
                        { name: '🛡️ Requested By', value: `${interaction.user.tag}`, inline: true }
                    ]
                });

                await interaction.editReply({ embeds: [embed] });
                console.log(`[HISTORY] Message history for ${user.tag} viewed by ${interaction.user.tag} in ${interaction.channel.name}`);
                break;
            }

            case 'about': {
                const embed = createEmbed({
                    color: CONFIG.COLORS.PRIMARY,
                    author: { 
                        name: 'META MOD',
                        iconURL: client.user.displayAvatarURL()
                    },
                    title: '🛡️ Professional Discord Moderation Bot',
                    description: 'META MOD is a powerful and professional moderation bot designed to help you manage your Discord server with ease and efficiency.',
                    thumbnail: client.user.displayAvatarURL({ size: 256 }),
                    fields: [
                        { 
                            name: '⚙️ Features', 
                            value: '• Member Management (Kick, Ban, Unban)\n• Timeout System\n• Message Management (Purge, History)\n• Professional Embeds & Logging\n• Permission-Based Commands', 
                            inline: false 
                        },
                        { 
                            name: '📊 Statistics', 
                            value: `• Servers: ${client.guilds.cache.size}\n• Users: ${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toLocaleString()}\n• Commands: ${commands.length}`, 
                            inline: true 
                        },
                        { 
                            name: '👑 Bot Owner', 
                            value: `<@${CONFIG.OWNER_ID}>`, 
                            inline: true 
                        },
                        { 
                            name: '🔗 Support Server', 
                            value: `[Join Here](${CONFIG.SUPPORT_SERVER})`, 
                            inline: true 
                        },
                        {
                            name: '📝 Commands',
                            value: '`/kick` `/ban` `/unban` `/timeout` `/untimeout` `/purge` `/history` `/about` `/support`',
                            inline: false
                        }
                    ]
                });

                await interaction.reply({ embeds: [embed] });
                break;
            }

            case 'support': {
                const embed = createEmbed({
                    color: CONFIG.COLORS.INFO,
                    author: { 
                        name: 'META MOD Support',
                        iconURL: client.user.displayAvatarURL()
                    },
                    title: '💬 Need Help?',
                    description: `Join our support server to get help, report bugs, or suggest new features!`,
                    thumbnail: client.user.displayAvatarURL({ size: 256 }),
                    fields: [
                        { 
                            name: '🔗 Support Server', 
                            value: `[Click here to join](${CONFIG.SUPPORT_SERVER})`, 
                            inline: false 
                        },
                        { 
                            name: '👑 Bot Owner', 
                            value: `<@${CONFIG.OWNER_ID}>`, 
                            inline: true 
                        },
                        { 
                            name: '📧 Contact', 
                            value: 'For direct support, contact the owner in our support server', 
                            inline: true 
                        },
                        {
                            name: '❓ Common Issues',
                            value: '• **Bot not responding?** Check bot permissions\n• **Commands not working?** Ensure you have the required role permissions\n• **Messages not deleting?** The bot needs "Manage Messages" permission',
                            inline: false
                        }
                    ]
                });

                await interaction.reply({ embeds: [embed] });
                break;
            }
        }
    } catch (error) {
        console.error(`Error executing ${commandName}:`, error);
        const errorEmbed = createErrorEmbed('An unexpected error occurred while executing this command. Please try again later.');
        
        if (interaction.deferred) {
            await interaction.editReply({ embeds: [errorEmbed] });
        } else if (!interaction.replied) {
            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
});

client.on('error', error => {
    console.error('Discord client error:', error);
});

if (!process.env.DISCORD_TOKEN) {
    console.error('❌ ERROR: DISCORD_TOKEN is not set in environment variables!');
    console.log('Please set your Discord bot token in the Secrets tab (DISCORD_TOKEN)');
    process.exit(1);
}

client.login(process.env.DISCORD_TOKEN).catch(error => {
    console.error('❌ Failed to login:', error);
    process.exit(1);
});
