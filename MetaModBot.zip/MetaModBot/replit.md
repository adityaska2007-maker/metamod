# Discord Moderation Bot - META MOD

## Overview

META MOD is a Discord moderation bot built with Discord.js v14 that provides comprehensive server moderation capabilities through slash commands. The bot enables server administrators and moderators to manage members, messages, and timeouts directly within Discord using modern slash command interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### October 1, 2025
- Implemented complete moderation command suite: kick, ban, unban, timeout, untimeout, purge, and history
- Added professional UI system with enhanced embeds and consistent branding
- Implemented color-coded embeds (Danger: red, Success: green, Warning: yellow, Info: blue)
- Added user avatar thumbnails to all moderation embeds
- Integrated owner ID and support server link into all embeds
- Created `/about` and `/support` commands for bot information
- Added DM protection to all commands with `setDMPermission(false)`
- Improved member fetching reliability using `await fetch()` instead of cache
- Added comprehensive error handling with professional error embeds
- Implemented console logging for all moderation actions
- Created workflow configuration for running the bot

## System Architecture

### Bot Framework
- **Technology**: Discord.js v14 (latest stable version)
- **Runtime**: Node.js 20
- **Command System**: Slash Commands (Discord's native command system)
- **Rationale**: Discord.js v14 provides modern APIs with full support for Discord's latest features, including native slash commands, improved permissions handling, and better error handling

### Gateway Intents
The bot uses specific gateway intents to minimize data transfer and improve performance:
- `Guilds`: Access to guild information
- `GuildMessages`: Message-related events
- `GuildMembers`: Member join/leave/update events
- `MessageContent`: Access to message content (required for message history feature)
- `GuildModeration`: Moderation-specific events (bans, kicks, timeouts)

**Rationale**: Only essential intents are enabled to reduce overhead and comply with Discord's privileged intent requirements

### Command Architecture
- **Pattern**: Slash Command Builders with global registration
- **Permission System**: Role-based permissions using Discord's native permission flags
- **Commands Implemented**:
  - `/kick`: Kick members from server (requires `KickMembers` permission)
  - `/ban`: Ban members from server (requires `BanMembers` permission)
  - `/unban`: Unban users by ID (requires `BanMembers` permission)
  - `/timeout`: Timeout members for specified duration in minutes (requires `ModerateMembers` permission)
  - `/untimeout`: Remove timeout from members (requires `ModerateMembers` permission)
  - `/purge`: Bulk delete messages (1-100) from channel (requires `ManageMessages` permission)
  - `/history`: View message history for specific users (requires `ManageMessages` permission)
  - `/about`: Display bot information and statistics
  - `/support`: Get support server link and help information
- **DM Protection**: All commands disabled in DMs via `setDMPermission(false)`
- **Member Fetching**: Uses reliable `await fetch()` for member resolution instead of cache

**Rationale**: Slash commands provide better UX with autocomplete, validation, and platform-wide consistency. Native permission checks ensure only authorized users can execute moderation actions.

### Deployment Model
- **Entry Point**: `index.js`
- **Process Model**: Single-process bot instance
- **State Management**: Stateless (no persistent storage)
- **Workflow**: "META MOD Bot" configured to run `node index.js`

## External Dependencies

### Discord.js Ecosystem
- **discord.js** (v14.x): Primary framework for Discord API interactions
  - Command builders and slash command support
  - Embed construction for formatted responses
  - REST API client for command registration
  - Utility functions and collections

### Discord API
- **Service**: Discord's Gateway and REST APIs
- **Authentication**: Bot token via `DISCORD_TOKEN` environment variable
- **Rate Limiting**: Handled automatically by discord.js library
- **API Version**: v10 (used by discord.js v14)

## Setup Requirements

### Required Configuration
1. **Discord Bot Token**: Set `DISCORD_TOKEN` in Replit Secrets
2. **Discord Developer Portal**:
   - Enable "Message Content Intent" (required for `/history` command)
   - Invite bot with proper scopes: `applications.commands` and `bot`
   - Grant necessary permissions: Kick Members, Ban Members, Moderate Members, Manage Messages

### Environment Variables
- `DISCORD_TOKEN`: Your Discord bot token from the Developer Portal

## Features

### Professional UI System
- **Enhanced Embeds**: All commands use professional, color-coded embeds with consistent branding
- **Color Scheme**: 
  - Danger (Red `#ED4245`): Kick, Ban actions
  - Success (Green `#57F287`): Unban, Untimeout actions
  - Warning (Yellow `#FEE75C`): Timeout actions
  - Info (Blue `#5DADE2`): Purge, History actions
  - Primary (Blurple `#5865F2`): About, general information
- **Visual Elements**: User avatars as thumbnails, formatted fields, timestamps on all embeds
- **Branding**: Consistent "META MOD" branding with support server link in all footers
- **Owner Integration**: Bot owner mention and support server link integrated throughout

### Moderation Commands
- **Member Management**: Kick, ban, and unban users with optional reasons
- **Timeout System**: Timeout users for custom durations or remove existing timeouts
- **Message Management**: Bulk delete messages and view user message history
- **Bot Information**: `/about` and `/support` commands for help and statistics
- **Logging**: All moderation actions logged to console with timestamps
- **Rich Embeds**: Professional visual feedback for all moderation actions

### Security & Reliability
- Permission-based access control
- Guild-only commands (no DM usage)
- Reliable member fetching with error handling
- Comprehensive error messages with professional error embeds
- Allowed mentions disabled to prevent accidental pings
